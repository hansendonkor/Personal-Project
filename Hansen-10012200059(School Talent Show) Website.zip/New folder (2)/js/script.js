// Change title background color on hover
const title = document.getElementById('event-title');
title.addEventListener('mouseover', () => {
  title.style.backgroundColor = '#00796b';
});
title.addEventListener('mouseout', () => {
  title.style.backgroundColor = 'transparent';
});